//
//  UserData.swift
//  eletmodvaltok
//
//  Created by Imre Ujlaki on 2017. 05. 06..
//  Copyright © 2017. CodeYard. All rights reserved.
//

import Foundation
import ObjectMapper

class UserData : BaseResponse {
    var id: String!
    var userName: String!
    var firstName: String!
    var lastName: String!
    var email: String!
    var yearOfBirth: String!
    var gender: String!
    var settlement: String!
    var modifyDate: Date!
    
    required init?(map: Map) {
        super.init(map: map)
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        id <- map["id"]
        userName <- map["username"]
        firstName <- map["first_name"]
        lastName <- map["last_name"]
        email <- (map["email"] == nil ? map["user_email"] : map["email"])
        yearOfBirth <- map["year_of_birth"]
        gender <- map["gender"]
        settlement <- map["settlement"]
        modifyDate <- map["modify_date"]
        
    }
    
    init(id: String = "", userName: String = "", firstName: String = "", lastName: String = "", email: String = "", yearOfBirth: String = "", gender: String = "", settlement: String = "") {
        super.init()!
        self.id = id
        self.firstName = firstName
        self.lastName  = lastName
        self.email = email
        self.yearOfBirth = yearOfBirth
        self.gender = gender
        self.settlement = settlement
    }
}
