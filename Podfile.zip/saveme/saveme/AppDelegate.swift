import UIKit
import SwiftyJSON
import Fabric
import Crashlytics

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    static var shared: AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        _ = Theme.shared
        self.window = UIWindow(frame: UIScreen.main.bounds)
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Splash", bundle: nil)
        UIApplication.shared.statusBarStyle = .lightContent
        let splashViewController = mainStoryboard.instantiateViewController(withIdentifier: "Root")
        self.window?.rootViewController = splashViewController
        self.window?.makeKeyAndVisible()
        
        
        let linkAction = UIMutableUserNotificationAction()
        linkAction.identifier = "showrun"
        linkAction.title = "Megnézem"
        linkAction.activationMode = UIUserNotificationActivationMode.foreground
        linkAction.isDestructive = false
        
        let linkCategory = UIMutableUserNotificationCategory()
        linkCategory.identifier = "linkCateg"
        linkCategory.setActions([linkAction], for: UIUserNotificationActionContext.default)
        linkCategory.setActions([linkAction], for: UIUserNotificationActionContext.minimal)
        
        application.registerUserNotificationSettings(UIUserNotificationSettings(types: [.alert , .badge , .sound], categories: Set(arrayLiteral: linkCategory)))
        
        Fabric.with([Crashlytics.self])
        
        return true
    }
    
    func application(_ application: UIApplication, didReceive notification: UILocalNotification) {
       
        print("\n\nUser notification received\n")
        
        // re-fetch programs and init notification again for next day to prevent un-opened app.
        
        if DataStore.shared.getAccessToken() != nil {
            RestClient.getUser(accessToken: DataStore.shared.getAccessToken()! , complitionBlock: { (error: String?, userResponse: UserResponse?) in
                if error == nil && userResponse!.userId != nil {
                    RestClient.getUserData(userId: userResponse!.userId, accessToken: DataStore.shared.getAccessToken()!, complitionBlock: { (error: String?, userDataResponse: UserDataResponse?) in
                        if error == nil {
                            DataStore.shared.userData = userDataResponse?.userData.first
                            DataStore.shared.subscriptions = userDataResponse?.userSubscriptions
                            RestClient.getPrograms(accessToken: DataStore.shared.getAccessToken()!, complitionBlock: { (err: String?, programs: [Program]?) in
                                    if programs != nil {
                                        DataStore.shared.programs = programs
                                    }
                            })
                        }
                    
                   })
               }
            })
        }
        
    }
   
    
    func application(_ application: UIApplication, handleActionWithIdentifier identifier: String?, for notification: UILocalNotification, completionHandler: @escaping () -> Void) {
        
        print(identifier!)
        print(notification.category!)
        
        // Point for handling the local notification Action. Provided alongside creating the notification.
        if identifier == "showrun" {
            print(notification.userInfo!["url"]!)
            UIApplication.shared.openURL(URL(string: notification.userInfo!["url"]! as! String)!)
        }
        
        completionHandler()
        
    }
    
      func registerForLocalNotification(day: Int, runday: Int, url1: String, url2: String) {
        
        print(day)
        print(runday)
        print(url1)
        print(url2)
        
        
        UIApplication.shared.scheduledLocalNotifications?.forEach({ (localNotification: UILocalNotification) in
            print("\n\nCancel notification for: \(localNotification.fireDate)")
            UIApplication.shared.cancelLocalNotification(localNotification)
        })
        
        if day > 0 && day < 43 {
            let notification = UILocalNotification()
            notification.fireDate = self.tomorrowMorning()
            print("Registered day for \(notification.fireDate)")
            notification.alertBody = "\(day). napi programod megérkezett!"
            notification.alertAction = "ok"
            notification.userInfo = ["day": day, "runday": 0, "url": ""]
            notification.soundName = UILocalNotificationDefaultSoundName
            UIApplication.shared.scheduleLocalNotification(notification)
        }
        
        if runday > 0 && runday < 43 {
            
            if url1 != "" {
                let notification = UILocalNotification()
                notification.fireDate = self.tomorrowMorning()
                print("Registered run1 for \(notification.fireDate)")
                if url2 != "" {
                    notification.alertBody = "\(runday). napi 5km programod megérkezett!"
                } else {
                    notification.alertBody = "\(runday). napi futás programod megérkezett!"
                }
                
                notification.alertAction = "showday"
                notification.category = "linkCateg"
                notification.userInfo = ["day": day, "runday": runday, "url":url1]
                notification.soundName = UILocalNotificationDefaultSoundName
                UIApplication.shared.scheduleLocalNotification(notification)
            }
            
            if url2 != "" {
                let notification = UILocalNotification()
                notification.fireDate = self.tomorrowMorning()
                print("Registered run2 for \(notification.fireDate)")
                notification.alertBody = "\(runday). napi 10 km programod megérkezett!"
                notification.alertAction = "showday"
                notification.category = "linkCateg"
                notification.userInfo = ["day": day, "runday": runday, "url":url2]
                notification.soundName = UILocalNotificationDefaultSoundName
                UIApplication.shared.scheduleLocalNotification(notification)
            }
        }
    }
    
    private func tomorrowMorning() -> Date? {
        let now = Date()
        var tomorrowComponents = DateComponents()
        tomorrowComponents.day = 1
        let calendar = Calendar.current
        if let tomorrow = calendar.date(byAdding: tomorrowComponents, to: now) {
            let components: Set<Calendar.Component> = [.era, .year, .month, .day, .hour, .minute]
            var tomorrowValidTime = calendar.dateComponents(components, from: tomorrow)
            tomorrowValidTime.hour = 9
            tomorrowValidTime.minute = 41
            if let tomorrowMorning = calendar.date(from: tomorrowValidTime)  {
                return tomorrowMorning
            }
            
        }
        return nil
    }
    
    private func nowplusthreemin() -> Date? {
        let now = Date()
        var tomorrowComponents = DateComponents()
        tomorrowComponents.minute = 2
        let calendar = Calendar.current
        if let tomorrow = calendar.date(byAdding: tomorrowComponents, to: now) {
            let components: Set<Calendar.Component> = [.era, .year, .month, .day, .hour, .minute]
            let tomorrowValidTime = calendar.dateComponents(components, from: tomorrow)
            //tomorrowValidTime.hour = 9
            //tomorrowValidTime.minute = 41
            if let tomorrowMorning = calendar.date(from: tomorrowValidTime)  {
                return tomorrowMorning
            }
            
        }
        return nil
    }
    
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    
}

