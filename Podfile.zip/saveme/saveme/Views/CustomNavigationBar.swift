//
//  CustomNavigationBar.swift
//  eletmodvaltok
//
//  Created by Imre Ujlaki on 2017. 05. 09..
//  Copyright © 2017. CodeYard. All rights reserved.
//

import Foundation
import UIKit

class CustomNavigationBar : UINavigationBar {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
    
    override func layoutSubviews() {
        
    }
}
