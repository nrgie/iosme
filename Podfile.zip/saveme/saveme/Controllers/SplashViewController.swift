//
//  SplashViewController.swift
//  eletmodvaltok
//
//  Created by Imre Ujlaki on 2017. 05. 05..
//  Copyright © 2017. CodeYard. All rights reserved.
//

import Foundation
import UIKit
import KYDrawerController

class SplashViewController : UIViewController {
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var modeLogo: UIImageView!
   
    override func viewDidLoad() {
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        if DataStore.shared.getAccessToken() != nil {
            RestClient.getUser(accessToken: DataStore.shared.getAccessToken()! , complitionBlock: { (error: String?, userResponse: UserResponse?) in
                if error == nil {
                    if userResponse!.userId != nil {
                        RestClient.getUserData(userId: userResponse!.userId, accessToken: DataStore.shared.getAccessToken()!, complitionBlock: { (error: String?, userDataResponse: UserDataResponse?) in
                            if error == nil {
                                DataStore.shared.userData = userDataResponse?.userData.first
                                DataStore.shared.subscriptions = userDataResponse?.userSubscriptions
                                NotificationCenter.default.post(name: Constants.Notifications.UserLoggedInNotification, object: nil, userInfo: nil)
                                self.showMainScreen()
                            } else {
                                MessageUtils.show(message: error!, with: "Error".localized, on: self)
                            }
                        })
                        DataStore.shared.setUserId(userId: userResponse!.userId)
                        
                    } else {
                        // no userid for saved token. do logout
                        DataStore.shared.clearData()
                        NotificationCenter.default.post(name: Constants.Notifications.UserLoggedOutNotification, object: nil, userInfo: nil)
                        self.showMainScreen()                    }
                } else {
                    MessageUtils.show(message: error!, with: "Error".localized, on: self)
                }
            })
        } else {
            self.showMainScreen()
        }
    }
    func showMainScreen(){
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let drawerController = mainStoryboard.instantiateViewController(withIdentifier: "DrawerController") as! KYDrawerController
        UIApplication.shared.delegate?.window??.rootViewController = drawerController
    }
}
