//
//  RunDaysViewController.swift
//  eletmodvaltok
//
//  Created by Tibi on 2017. 06. 25..
//  Copyright © 2017. All rights reserved.
//

import UIKit

class RunDaysViewController: UITableViewController {

    var data: [RunDay]? = []
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        self.clearsSelectionOnViewWillAppear = true
        
        RestClient.getRundays(accessToken: DataStore.shared.getAccessToken()!, complitionBlock: { (err: String?, days: [RunDay]?) in
            if days != nil {
                
                self.data = days?.reversed()
                self.tableView.estimatedRowHeight = 370
                self.tableView.rowHeight = UITableViewAutomaticDimension
                self.tableView.reloadData()
                
            }
        })
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 350.0
    }
 
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> RunDayCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "rundaycell") as! RunDayCell
        cell.day = data?[indexPath.row]
        
        return cell
    }
    
}
