//
//  CustomNavigationController.swift
//  eletmodvaltok
//
//  Created by Imre Ujlaki on 2017. 05. 12..
//  Copyright © 2017. CodeYard. All rights reserved.
//

import Foundation
import UIKit

class CustomNavigationController : UINavigationController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
